## Prompt 1
Jelaskan struktur data graf dan jenis-jenis graf dalam ilmu komputer.

## Prompt 2
Berikan implementasi struktur data graf menggunakan Python.

## Prompt 3
Buatlah algoritma pencarian jalur (BFS dan DFS) dalam graf dengan Python.

## Prompt 4
Bagaimana graf digunakan dalam pencarian rute di Google Maps?
