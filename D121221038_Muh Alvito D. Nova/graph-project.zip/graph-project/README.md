# Struktur Data: Graf

## Deskripsi
Proyek ini mengeksplorasi struktur data graf, termasuk representasi, operasi dasar, dan penerapan algoritma pencarian jalur seperti BFS dan DFS. Studi kasus yang digunakan adalah pencarian rute tercepat dalam peta jaringan transportasi.

## Bahasa Pemrograman
Python

## Studi Kasus
Platform: Google Maps (konsep graf untuk rute transportasi)

## Tujuan
- Memahami struktur data graf.
- Menggunakan AI (ChatGPT) untuk membantu menyusun solusi awal.
- Memodifikasi solusi AI agar lebih optimal dan relevan dengan studi kasus.
