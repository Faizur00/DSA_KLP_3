# Representasi graf: simpul sebagai lokasi, sisi sebagai jalan
graph = {
    'Terminal': ['Pasar', 'Sekolah'],
    'Pasar': ['Terminal', 'Rumah Sakit'],
    'Sekolah': ['Terminal', 'Rumah Sakit'],
    'Rumah Sakit': ['Pasar', 'Sekolah']
}

def bfs_route(graph, start, goal):
    visited = []
    queue = [[start]]
    while queue:
        path = queue.pop(0)
        node = path[-1]
        if node == goal:
            return path
        elif node not in visited:
            for neighbor in graph[node]:
                new_path = list(path)
                new_path.append(neighbor)
                queue.append(new_path)
            visited.append(node)
    return None

# Contoh pencarian rute
print("Rute dari Terminal ke Rumah Sakit:", bfs_route(graph, 'Terminal', 'Rumah Sakit'))
